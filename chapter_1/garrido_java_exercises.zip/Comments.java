public class Comments {
    public static void main(String[] args) {
        // This is a single-line comment

        /* This is a 
           multi-line comment */

        /**
         * This is a documentation comment
         * It is often used for describing classes and methods
         */
        
        System.out.println("Comments in Java are ignored by the compiler!");
    }
}