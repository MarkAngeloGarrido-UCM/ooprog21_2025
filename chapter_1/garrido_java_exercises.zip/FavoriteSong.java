public class FavoriteSong {
    public static void main(String[] args) {
        System.out.println("Memories");
        System.out.println("Sugar");
        System.out.println("Payphone");
        System.out.println("She Will Be Loved");
    }
}